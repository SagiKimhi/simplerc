# SimpleRC - A Simple Resource Management Package in Python
# ---------------------------------------------------------

## General:
## --------
Small general lightweight package for sharing and managing resources.
Not sure for how long development will continue on this package,
this is just useful for me for the time being and I like to share
so hopefuly this will be helpful for others as well.

## Regarding license and legal stuff: 
## ----------------------------------
The formal license is Apache Version 2.0
The non-formal license is I couldn't care less about legal stuff

As long as it doesnt hurt me or others in anyway, use this as you please,
License is simply there so that it can also be useful for commercial use.

I'm not using any external packages or dependencies other then Python
built-in modules both to keep my head, email, and repo clean, as well as
to allow myself and others to use it for whatever reason or need.

## Regarding Development
## ---------------------
As of writing this, this is just a simple utility and im not planning
to continue development currently on a daily/weekly and can't tell whether
or not I will forget about this and when.

In any case, as long as no security issues are found, I don't think its an
issue.
There really isn't nothing much here and I don't see how it can break even
w/o me working on it in the future (
    Yes I can hear the future me yelling and regretting that last sentence,
    but thats future me sc**w that dude. Thats the model - I break and make
    big mess, future fix and make all pretty and makes sure to leave some
    mess for his future to handle.
)

## Even though development may be minimal (Regarding Issues and pull requests)
## ---------------------------------------------------------------------------
In any case, Issues and additions are welcome.
Furthermore, if it is a security issue, bug, an elegant optimization,
or even just a better more correct way of doing things, please share
it and create an issue/pull request.

In other words, as long as its not some sort of 'BRUHHHH NOT WORKING PLEASE
FIX NEED HELP CUZ CANT USE STACKOVERFLOW CUZ BLOCKED FOR NO REASON',
then feel free to post it.

I haven't defined a format for requests/issues (and probably never will) in
order to keep discussions open and encourage contributions and involvement
of the community.

If you implemented something, fixed something, found a meaningfull bug/issue,
simplified, cleaned, optimized, organized, or did anything else that can help
and/or educate myself and others, I appreciate it.

If I haven't merged your pull request, its not necessarily because i don't
think I should, but most likely because I haven't  seen it or because I can't
understand it yet (won't put something I can't understand in a codebase myself
and others use and risk breaking other people's code unless I truly trust
you and your skillset), or because I love it but simply think it is too
complex for such simple lightweight package, or to complex for me to keep
maintaining in the future if this pkg turns out to actually be useful.

If it is the last described scenario ill probably also recommend creating
a seperate repo and adding a recommendation for it directly in mine.
Further more, if it truly is useful and elegant but simply not something I 
can maintain myself, ill be happy to add it as an optional dependency in
addition to the recommendation (went kinda far thinking this package will
even reach or help anyone in the future, huh, I wonder...)

Finally
-------
Whoever you are,
wherever you are,
whatever your race is,
whatever your gender is...

Please be kind.
Please be humble.

Please help others in need, if you can.
Please don't help others if it'll hurt you.
Please stop helping others, if they are only using you.

Speak the truth, it may hurt, but its the truth.
Speak the factual truth, not the way you see things from your prespective.

We are all human.
We are all beautiful.
We are also all complete trash, each in its own way.

For better or worse, 
we are what we are,
we are who we are,
we are where we are.

Where we are doesn't always tell where we'll be,
and when it does, it still doesnt tell that we can't do
something to serve others in the future.

Be your own best, its enough, 
and its your best, what else can be done.

Be your own best, 
and let others be theirs, 
they are not you, and you are not them.

Please, understand, 
mistakes are teachers,
and it is important we make them, 
it is also important we don't ignore them.

Judge yourself, as harsh as you judge others.
Accept yourself, as much as you accept others.
If you don't accept others, 
you are most likely just hurting yourself - they don't care...

Forgive yourself, forgive others,
it isn't about whether or not someone deserves forgiveness,
it is about us who deserve to move on,
to release hatered, to open our hearts again,
the mean and the evil were found in the past,
the mean and the evil will also be found in the future,
hatered does not make things better, and may also create worse...

The world isn't perfect,
it never got close to perfect,
it wasn't meant to be perfect,
it doesn't matter what is meant to be,
what is there today is there, embrace it.

perfect is a truth of my mind,
not a truth of reality...
it is the way I vision a purity of some kind,
but it is simply a vision, it may be nice to vision, 
but thats the end of it, to speak the truth, I must release it.

No matter how important you are,
no matter how wise you are,
no matter how spiritual you are,
no matter how many times you were right,
there's always an edgecase,
there's always some bug,
there's always benefit to observing, 
reviewing, stopping, planning, thinking before we act.

Some time the best is to simply try something out and let shit happen,
seeing it rolling, turning into a mess, figuring it out and cleaning up,
is many times natural, and exactly what you need.

I love you all.

Fuck you all as well.

As long as we're there for each other in need,
then that is our truth, and so for now, i'm glad to be hated.

Have a great day, 
and if you've read this far,
then understand, 
people like us are why we're behind on schedule,
what will you say at the daily? "I read an entire readme on github"?
bruh...
and yet thank you and much love ;)

"""


